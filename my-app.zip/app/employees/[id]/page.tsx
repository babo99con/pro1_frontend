"use client";

import EmployeeDetailPage from "@/features/employee-detail/ui/EmployeeDetailPage";

export default function Page() {
  return (
    <main>
      <EmployeeDetailPage />
    </main>
  );
}
