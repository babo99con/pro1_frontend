"use client";

import EmployeeListPage from "@/features/employee-list/ui/EmployeeListPage";

export default function Page() {
  return (
    <main>
      <EmployeeListPage />
    </main>
  );
}
