"use client";

export { default } from "@/features/employee-register/ui/EmployeeRegisterPage";
