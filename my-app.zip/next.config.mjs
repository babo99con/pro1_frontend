/** @type {import('next').NextConfig} */
const nextConfig = {
  // config options...
}

export default nextConfig;
